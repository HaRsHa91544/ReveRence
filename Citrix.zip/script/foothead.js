$(document).ready(function(){
    $("#navbar").load("header.html");
    $("#footer").load("footer.html");
});